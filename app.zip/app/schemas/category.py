from pydantic import BaseModel, ConfigDict

class CategoryBase(BaseModel):
    name: str

class CategoryDisplay(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    
    name: str